/**
 * 
 */
package prj5;

/**
 * @author aphen
 * @version <4/17/17>
 */
public enum CategoryEnum {
    /**
     * Represents each Category
     */
    Hobby, Major, Region;
}

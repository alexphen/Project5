package prj5;

public enum HobbyEnum {

    /**
     * Enums that decide the state of a person's hobby
     */
    READ, SPORTS, ART, MUSIC;
}

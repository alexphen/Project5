package prj5;

public enum MajorEnum {
    /**
     * The major of a person
     */
    COMPUTER_SCIENCE, OTHER_ENGE, MATH_CMDA, OTHER;
}

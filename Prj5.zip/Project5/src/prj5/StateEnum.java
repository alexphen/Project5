package prj5;

public enum StateEnum {
    /**
     * Where a person can live
     */
    NORTHEAST, SOUTHEAST, OTHER_US, OTHER;
}

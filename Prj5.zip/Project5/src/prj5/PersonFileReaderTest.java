package prj5;


import java.io.File;

/**
 * 
 * @author Adam Tapp adamt
 * @version 04/20/2017
 */
public class PersonFileReaderTest extends student.TestCase {
    /**
     * PersonFileReaderTest field
     */
    private PersonFileReader pFR;


    /**
     * PersonList field
     */
    private PersonList personList;


    /**
     * Sets up the initial conditions for the test
     */
    public void setUp() {
        File file = new File("MusicSurveyData.csv");
        pFR = new PersonFileReader(file);
        personList = new PersonList();
    }

    /**
     * Tests readPersonFile, which returns a list of 
     * people created from the given file
     */
    public void testReadPersonFile() {
        personList = pFR.readPersonFile();
        assertEquals(205, personList.size());
        
        Person person = personList.get(0);
        assertEquals(MajorEnum.MATH_CMDA, person.getMajor());
        assertEquals(StateEnum.SOUTHEAST, person.getState());
        assertEquals(HobbyEnum.SPORTS, person.getHobby());
        
        File file1 = new File("ThisIsNotARealFile.csv");
        pFR = new PersonFileReader(file1);
        PersonList personList1 = new PersonList();
        assertEquals(personList1.toString(), pFR.readPersonFile().toString());
        
        
    }

}
